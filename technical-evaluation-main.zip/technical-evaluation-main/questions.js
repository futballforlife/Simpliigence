/* =====================================================================
   Technical Evaluation – Question Bank
   ---------------------------------------------------------------------
   MCQ  : auto-scored (1 correct option each)
   CODE : free-text answer, graded by the organizer on organizer.html
   Sets : SETS[n] lists the question ids for "Set n" (7 MCQ + 3 CODE)
   ===================================================================== */

const MCQ = {
  /* ---------------- SQL ---------------- */
  sql1: {
    topic: "SQL",
    q: "Employee table: (1, A, 50000), (2, B, 70000), (3, C, 80000). Which query returns the SECOND highest salary and also works on SQL Server (no LIMIT/OFFSET)?",
    options: [
      "SELECT MAX(Salary) FROM Employee WHERE Salary < (SELECT MAX(Salary) FROM Employee);",
      "SELECT Salary FROM Employee ORDER BY Salary DESC LIMIT 1 OFFSET 1;",
      "SELECT MIN(Salary) FROM Employee;",
      "SELECT Salary FROM Employee WHERE Salary = 2;"
    ],
    answer: 0,
    explain: "MAX below the overall MAX gives the second highest (70000) on any RDBMS."
  },
  sql2: {
    topic: "SQL",
    q: "Using the same Employee table, what value does this query return?",
    code: "SELECT MAX(Salary) FROM Employee\nWHERE Salary < (SELECT MAX(Salary) FROM Employee);",
    options: ["80000", "70000", "50000", "NULL"],
    answer: 1,
    explain: "Overall max is 80000; the highest salary below that is 70000."
  },
  sql3: {
    topic: "SQL",
    q: "Which query returns the full record(s) of the employee(s) with the highest salary, INCLUDING ties?",
    options: [
      "SELECT * FROM Employee WHERE Salary = (SELECT MAX(Salary) FROM Employee);",
      "SELECT * FROM Employee ORDER BY Salary DESC LIMIT 1;",
      "SELECT TOP 1 * FROM Employee ORDER BY Salary DESC;",
      "SELECT MAX(*) FROM Employee;"
    ],
    answer: 0,
    explain: "The subquery form returns every row whose salary equals the max, so ties are kept."
  },
  sql4: {
    topic: "SQL",
    q: "Which window function assigns rank 2 to the second highest DISTINCT salary even when two employees share the top salary?",
    options: ["DENSE_RANK()", "ROW_NUMBER()", "COUNT()", "NTILE(2)"],
    answer: 0,
    explain: "DENSE_RANK has no gaps, so the second distinct salary is always rank 2."
  },
  sql5: {
    topic: "SQL",
    q: "Table Person(id, email). Which query lists duplicate emails?",
    options: [
      "SELECT email FROM Person GROUP BY email HAVING COUNT(*) > 1;",
      "SELECT DISTINCT email FROM Person;",
      "SELECT email FROM Person WHERE COUNT(email) > 1;",
      "SELECT email, COUNT(*) FROM Person WHERE COUNT(*) > 1;"
    ],
    answer: 0,
    explain: "Aggregate filters must go in HAVING, not WHERE."
  },
  sql6: {
    topic: "SQL",
    q: "In SQL Server, which keyword replaces MySQL's LIMIT 1 to return only the first row?",
    options: ["TOP 1", "FIRST 1", "ROWNUM 1", "LIMIT 1 works in SQL Server"],
    answer: 0,
    explain: "SQL Server uses SELECT TOP 1 ... (or OFFSET/FETCH)."
  },
  sql7: {
    topic: "SQL",
    q: "What does this query return for the sample Employee table (50000, 70000, 80000)?",
    code: "SELECT Name FROM Employee\nORDER BY Salary DESC LIMIT 1 OFFSET 1;",
    options: ["A", "B", "C", "Error"],
    answer: 1,
    explain: "Sorted descending: C(80000), B(70000), A(50000); skipping one row returns B."
  },
  sql8: {
    topic: "SQL",
    q: "Which clause is evaluated AFTER GROUP BY and can filter on aggregate values?",
    options: ["HAVING", "WHERE", "ORDER BY", "DISTINCT"],
    answer: 0,
    explain: "WHERE filters rows before grouping; HAVING filters groups."
  },

  /* ---------------- C# / ADO.NET ---------------- */
  cs1: {
    topic: "C# / ADO.NET",
    q: "Which ADO.NET approach prevents SQL injection when inserting user-supplied values?",
    options: [
      "Use @parameters with SqlCommand.Parameters.AddWithValue / Add",
      "Concatenate the values into the SQL string with '+'",
      "Use string.Format to build the INSERT statement",
      "Escape single quotes manually with Replace(\"'\", \"''\")"
    ],
    answer: 0,
    explain: "Parameterized commands send values separately from the SQL text."
  },
  cs2: {
    topic: "C# / ADO.NET",
    q: "Which SqlCommand method is the correct one to execute an INSERT statement?",
    options: ["ExecuteNonQuery()", "ExecuteReader()", "ExecuteScalar()", "ExecuteXmlReader()"],
    answer: 0,
    explain: "ExecuteNonQuery runs INSERT/UPDATE/DELETE and returns the affected row count."
  },
  cs3: {
    topic: "C# / ADO.NET",
    q: "What is the purpose of wrapping SqlConnection in a using block?",
    options: [
      "The connection is closed/disposed automatically even if an exception occurs",
      "It makes the query run faster",
      "It enables parameterized queries",
      "It automatically retries on failure"
    ],
    answer: 0,
    explain: "using calls Dispose() at the end of the block, which closes the connection."
  },
  cs4: {
    topic: "C# / ADO.NET",
    q: "Which exception type is most specific for catching SQL Server errors in ADO.NET?",
    options: ["SqlException", "IOException", "NullReferenceException", "HttpException"],
    answer: 0,
    explain: "SqlException is thrown by the SqlClient provider for database errors."
  },
  cs5: {
    topic: "C# / ADO.NET",
    q: "What is wrong with this code?",
    code: "string sql = \"INSERT INTO Employee (Name, Salary) VALUES ('\" + name + \"', \" + salary + \")\";\nvar cmd = new SqlCommand(sql, conn);\ncmd.ExecuteNonQuery();",
    options: [
      "It is vulnerable to SQL injection because values are concatenated",
      "ExecuteNonQuery cannot be used for INSERT",
      "SqlCommand requires ExecuteReader for INSERT",
      "Nothing – this is the recommended pattern"
    ],
    answer: 0,
    explain: "A name like  x'); DROP TABLE Employee;--  would be executed."
  },
  cs6: {
    topic: "C# / ADO.NET",
    q: "What does ExecuteNonQuery() return after a successful single-row INSERT?",
    options: ["1 (number of rows affected)", "The inserted row", "true", "The new identity value"],
    answer: 0,
    explain: "It returns the count of affected rows."
  },
  cs7: {
    topic: "C# / ADO.NET",
    q: "Before calling cmd.ExecuteNonQuery(), which call is required on the SqlConnection?",
    options: ["conn.Open()", "conn.Connect()", "conn.Start()", "None – it opens automatically"],
    answer: 0,
    explain: "The connection must be explicitly opened."
  },

  /* ---------------- Python ---------------- */
  py1: {
    topic: "Python",
    q: "In Pascal's Triangle, how is each interior value of row r computed?",
    options: [
      "Sum of the two values directly above it: row[r-1][c-1] + row[r-1][c]",
      "Product of the two values above it",
      "row number × column number",
      "Previous value in the same row + 1"
    ],
    answer: 0,
    explain: "Each row starts and ends with 1; interior values are the sum of the two above."
  },
  py2: {
    topic: "Python",
    q: "What is printed?",
    code: "row = [1]\nfor _ in range(4):\n    row = [1] + [row[i] + row[i+1] for i in range(len(row)-1)] + [1]\nprint(row)",
    options: ["[1, 4, 6, 4, 1]", "[1, 3, 3, 1]", "[1, 5, 10, 10, 5, 1]", "[1, 2, 1]"],
    answer: 0,
    explain: "Four iterations from [1] produce row 5 of Pascal's Triangle: 1 4 6 4 1."
  },
  py3: {
    topic: "Python",
    q: "Which exception must be caught so that non-integer input to int(input()) is reported gracefully?",
    options: ["ValueError", "TypeError", "KeyError", "SyntaxError"],
    answer: 0,
    explain: "int('abc') raises ValueError."
  },
  py4: {
    topic: "Python",
    q: "To check whether n is prime efficiently, up to which value do you need to test divisors?",
    options: ["√n (int(n**0.5))", "n - 1", "n / 2 always", "log n"],
    answer: 0,
    explain: "Any composite number has a factor ≤ its square root."
  },
  py5: {
    topic: "Python",
    q: "What is the output?",
    code: "def is_prime(n):\n    if n <= 1: return False\n    for i in range(2, int(n**0.5)+1):\n        if n % i == 0: return False\n    return True\nprint(is_prime(1), is_prime(2), is_prime(9))",
    options: ["False True False", "True True False", "False True True", "True False False"],
    answer: 0,
    explain: "1 is not prime, 2 is prime, 9 = 3×3 is not prime."
  },
  py6: {
    topic: "Python",
    q: "What does this print?",
    code: "s = \"aabbcdd\"\nfrom collections import Counter\nc = Counter(s)\nprint(next(ch for ch in s if c[ch] == 1))",
    options: ["c", "a", "d", "b"],
    answer: 0,
    explain: "'c' is the only character appearing exactly once."
  },
  py7: {
    topic: "Python",
    q: "What does this print?",
    code: "print(\"Apple\".lower().index(\"p\"))",
    options: ["1", "2", "0", "-1"],
    answer: 0,
    explain: "Python uses 0-based indexing: A=0, p=1."
  },
  py8: {
    topic: "Python",
    q: "Which expression correctly checks if two strings are anagrams (ignoring case)?",
    options: [
      "sorted(a.lower()) == sorted(b.lower())",
      "a.lower() == b.lower()[::-1]",
      "set(a) == set(b)",
      "len(a) == len(b)"
    ],
    answer: 0,
    explain: "Sorting both strings compares the exact multiset of letters. set() ignores counts."
  },
  py9: {
    topic: "Python",
    q: "What is printed?",
    code: "n = 5\nprint(\"*\" * (2*3 - 1))",
    options: ["*****", "***", "******", "*********"],
    answer: 0,
    explain: "2*3-1 = 5 stars – the 3rd row of a star pyramid."
  },
  py10: {
    topic: "Python",
    q: "Given arr = [1, 2, 3, 5] and N = 5, which expression finds the missing number?",
    options: [
      "N*(N+1)//2 - sum(arr)",
      "sum(arr) - N",
      "max(arr) - min(arr)",
      "len(arr) - N"
    ],
    answer: 0,
    explain: "Expected sum 1..5 = 15, actual sum = 11, missing = 4."
  },
  py11: {
    topic: "Python",
    q: "What does this print?",
    code: "print(\"aabbccdefggd\".count(\"g\"), \"aabbccdefggd\"[6])",
    options: ["2 d", "2 e", "1 d", "3 d"],
    answer: 0,
    explain: "'g' appears twice; index 6 is 'd' (a a b b c c d ...)."
  },
  py12: {
    topic: "Python",
    q: "What does this print?",
    code: "for i in range(1, 4):\n    print(\" \".join(str(x) for x in list(range(i, 0, -1)) + list(range(2, i+1))))",
    options: [
      "1\\n2 1 2\\n3 2 1 2 3",
      "1\\n1 2\\n1 2 3",
      "1\\n2 1\\n3 2 1",
      "1 2 3\\n2 1 2\\n1"
    ],
    answer: 0,
    explain: "Each row counts down from i to 1, then back up to i."
  },
  py13: {
    topic: "Python",
    q: "Which is the first character of the LONGEST consecutive repeating group in \"aaabbbbccdd\"?",
    options: ["b", "a", "c", "d"],
    answer: 0,
    explain: "Groups: aaa(3), bbbb(4), cc(2), dd(2) – 'bbbb' is longest."
  },
  py14: {
    topic: "Python",
    q: "For nums = [1,1,1,2,2,3,4,4,4,4] and k = 2, the top-k frequent elements are:",
    options: ["[4, 1]", "[1, 2]", "[4, 2]", "[3, 4]"],
    answer: 0,
    explain: "4 appears 4 times, 1 appears 3 times."
  },
  py15: {
    topic: "Python",
    q: "Which built-in raises the error caught here?",
    code: "try:\n    n = int(input(\"Enter: \"))\nexcept ValueError:\n    print(\"Not a number\")",
    options: ["int()", "input()", "print()", "try"],
    answer: 0,
    explain: "input() always returns a str; int() fails on non-numeric text."
  },

  /* ---------------- Java ---------------- */
  jv1: {
    topic: "Java",
    q: "In a Java Servlet, which method handles an HTML form submitted with method=\"POST\"?",
    options: ["doPost(HttpServletRequest, HttpServletResponse)", "doGet(...)", "service() only", "init()"],
    answer: 0,
    explain: "doPost is invoked for HTTP POST requests."
  },
  jv2: {
    topic: "Java",
    q: "How does a servlet read the value of <input name=\"username\"> from the request?",
    options: [
      "request.getParameter(\"username\")",
      "request.getAttribute(\"username\")",
      "request.getHeader(\"username\")",
      "response.getParameter(\"username\")"
    ],
    answer: 0,
    explain: "Form fields arrive as request parameters."
  },
  jv3: {
    topic: "Java",
    q: "Which object writes HTML output (e.g. a welcome message) back to the browser?",
    options: [
      "PrintWriter from response.getWriter()",
      "System.out",
      "request.getWriter()",
      "HttpSession"
    ],
    answer: 0,
    explain: "response.getWriter() returns a PrintWriter for character output."
  },
  jv4: {
    topic: "Java",
    q: "What is the output?",
    code: "String s = \"Apple\";\nSystem.out.println(s.indexOf('p') + \" \" + s.toUpperCase().indexOf('P'));",
    options: ["1 1", "2 2", "1 -1", "-1 1"],
    answer: 0,
    explain: "indexOf is 0-based; lowercase 'p' is at 1; after upper-casing, 'P' is also at 1."
  },
  jv5: {
    topic: "Java",
    q: "Which annotation maps a servlet to the URL /login without web.xml?",
    options: ["@WebServlet(\"/login\")", "@RequestMapping(\"/login\")", "@Servlet(\"/login\")", "@Path(\"/login\")"],
    answer: 0,
    explain: "@WebServlet is the Servlet 3.0 annotation."
  },
  jv6: {
    topic: "Java",
    q: "What does this print?",
    code: "int[] arr = {1, 2, 3, 5}; int n = 5;\nint sum = 0; for (int x : arr) sum += x;\nSystem.out.println(n * (n + 1) / 2 - sum);",
    options: ["4", "5", "11", "15"],
    answer: 0,
    explain: "15 - 11 = 4, the missing number."
  },
  jv7: {
    topic: "Java",
    q: "In the login form HTML, which attribute pair makes the browser send data to the servlet as a POST?",
    options: [
      "<form action=\"login\" method=\"post\">",
      "<form href=\"login\" type=\"post\">",
      "<form action=\"login\" method=\"get\">",
      "<form submit=\"login\">"
    ],
    answer: 0,
    explain: "action gives the URL; method=\"post\" sends the body as a POST."
  },

  /* ---------------- JavaScript ---------------- */
  js1: {
    topic: "JavaScript",
    q: "What is logged?",
    code: "console.log(\"Apple\".indexOf(\"p\"), \"Apple\".indexOf(\"P\"));",
    options: ["1 -1", "1 1", "2 -1", "-1 1"],
    answer: 0,
    explain: "indexOf is case-sensitive and 0-based; there is no uppercase 'P' in \"Apple\"."
  },
  js2: {
    topic: "JavaScript",
    q: "What is logged?",
    code: "const s = \"aabbcdd\";\nconst first = [...s].find(c => s.indexOf(c) === s.lastIndexOf(c));\nconsole.log(first);",
    options: ["c", "a", "d", "undefined"],
    answer: 0,
    explain: "A character that occurs once has equal first and last index."
  },
  js3: {
    topic: "JavaScript",
    q: "Which snippet checks whether \"listen\" and \"silent\" are anagrams?",
    options: [
      "[...a].sort().join('') === [...b].sort().join('')",
      "a.split('').reverse().join('') === b",
      "a.length === b.length",
      "new Set(a).size === new Set(b).size"
    ],
    answer: 0,
    explain: "Sorting the characters of both strings normalises them for comparison."
  },
  js4: {
    topic: "JavaScript",
    q: "What is logged?",
    code: "console.log([1, 2, 3, 5].reduce((a, b) => a + b, 0));",
    options: ["11", "15", "4", "1235"],
    answer: 0,
    explain: "1+2+3+5 = 11."
  },
  js5: {
    topic: "JavaScript",
    q: "What does this print?",
    code: "for (let i = 1; i <= 3; i++) console.log(\"*\".repeat(2 * i - 1));",
    options: ["*\\n***\\n*****", "*\\n**\\n***", "***\\n***\\n***", "*****\\n***\\n*"],
    answer: 0,
    explain: "Rows of 1, 3 and 5 stars – a left-aligned increasing pyramid."
  },
  js6: {
    topic: "JavaScript",
    q: "What is logged?",
    code: "const m = {};\nfor (const c of \"aabbbc\") m[c] = (m[c] || 0) + 1;\nconsole.log(Object.entries(m).sort((x, y) => y[1] - x[1])[0][0]);",
    options: ["b", "a", "c", "3"],
    answer: 0,
    explain: "Frequencies a:2, b:3, c:1 – the most frequent is 'b'."
  },

  /* ---------------- Salesforce ---------------- */
  sf1: {
    topic: "Salesforce (LWC & Apex)",
    q: "In an LWC placed on an Account record page, which decorator exposes the current record's Id to the component?",
    options: ["@api recordId", "@track recordId", "@wire recordId", "@AuraEnabled recordId"],
    answer: 0,
    explain: "The record page injects the Id into a public @api recordId property."
  },
  sf2: {
    topic: "Salesforce (LWC & Apex)",
    q: "An Apex method used by an LWC to fetch Contacts must be annotated with:",
    options: [
      "@AuraEnabled(cacheable=true)",
      "@RemoteAction",
      "@InvocableMethod",
      "@future"
    ],
    answer: 0,
    explain: "@AuraEnabled exposes it to LWC; cacheable=true is required for @wire."
  },
  sf3: {
    topic: "Salesforce (LWC & Apex)",
    q: "Which function re-runs a @wire'd Apex call so the Refresh button shows the latest data?",
    options: ["refreshApex(this.wiredResult)", "this.refresh()", "window.location.reload()", "getRecord()"],
    answer: 0,
    explain: "refreshApex from @salesforce/apex re-provisions the wired value."
  },
  sf4: {
    topic: "Salesforce (LWC & Apex)",
    q: "How does an LWC display an error toast?",
    options: [
      "this.dispatchEvent(new ShowToastEvent({title, message, variant: 'error'}))",
      "alert(message)",
      "console.error(message)",
      "this.showToast(message)"
    ],
    answer: 0,
    explain: "ShowToastEvent is imported from lightning/platformShowToastEvent and dispatched."
  },
  sf5: {
    topic: "Salesforce (LWC & Apex)",
    q: "Which parameter types can an @future Apex method accept?",
    options: [
      "Primitive types, collections of primitives (e.g. List<Id>) – NOT sObjects",
      "Any sObject such as Account",
      "List<Account> only",
      "No parameters at all"
    ],
    answer: 0,
    explain: "@future methods cannot take sObjects; pass record Ids instead."
  },
  sf6: {
    topic: "Salesforce (LWC & Apex)",
    q: "Which trigger context should be used to send a welcome email after an Account is created?",
    options: ["after insert", "before insert", "before update", "after delete"],
    answer: 0,
    explain: "After insert, records have Ids and are committed to the trigger context."
  },
  sf7: {
    topic: "Salesforce (LWC & Apex)",
    q: "Which Apex class/method sends emails?",
    options: ["Messaging.sendEmail()", "Email.send()", "System.mail()", "Database.sendMail()"],
    answer: 0,
    explain: "Messaging.sendEmail with SingleEmailMessage instances."
  },
  sf8: {
    topic: "Salesforce (LWC & Apex)",
    q: "Which base component renders tabular data with columns defined in JavaScript?",
    options: ["lightning-datatable", "lightning-table", "lightning-grid", "lightning-list"],
    answer: 0,
    explain: "lightning-datatable takes data and columns properties."
  }
};

const CODE = {
  c_sql_second: {
    topic: "SQL",
    title: "Second highest salary",
    q: "Using the Employee table (EmpId, Name, Salary), write a SQL query to find the SECOND highest salary. Your solution must NOT rely on LIMIT/OFFSET (use a subquery or window function) so it also works on SQL Server.",
    model: "SELECT MAX(Salary) FROM Employee WHERE Salary < (SELECT MAX(Salary) FROM Employee);\n-- or\nSELECT Salary FROM (SELECT Salary, DENSE_RANK() OVER (ORDER BY Salary DESC) rnk FROM Employee) t WHERE rnk = 2;",
    rubric: "Full marks: correct, portable (no LIMIT). Partial: correct only with LIMIT/OFFSET, or minor syntax slips."
  },
  c_sql_highest: {
    topic: "SQL",
    title: "Highest-paid employee record",
    q: "Write a SQL query to retrieve the full record(s) of the employee(s) with the highest salary in the Employee table (ties should be included).",
    model: "SELECT * FROM Employee WHERE Salary = (SELECT MAX(Salary) FROM Employee);",
    rubric: "Full marks if ties are handled. Partial for ORDER BY ... LIMIT 1 / TOP 1."
  },
  c_sql_dup: {
    topic: "SQL",
    title: "Duplicate emails",
    q: "Table Person(id, email). Write a SQL query that returns all emails that appear more than once.",
    model: "SELECT email FROM Person GROUP BY email HAVING COUNT(*) > 1;",
    rubric: "Full marks for GROUP BY + HAVING (or self-join). Partial for WHERE COUNT attempt with right idea."
  },
  c_cs_insert: {
    topic: "C# / ADO.NET",
    title: "Parameterized INSERT with ADO.NET",
    q: "Write a C# snippet using ADO.NET (SqlConnection and SqlCommand) that inserts a new record into a SQL Server table. Use parameterized values (not string concatenation) and include basic error handling.",
    model: "try {\n  using (var conn = new SqlConnection(connStr))\n  using (var cmd = new SqlCommand(\"INSERT INTO Employee (Name, Salary) VALUES (@Name, @Salary)\", conn)) {\n    cmd.Parameters.AddWithValue(\"@Name\", name);\n    cmd.Parameters.AddWithValue(\"@Salary\", salary);\n    conn.Open();\n    int rows = cmd.ExecuteNonQuery();\n  }\n} catch (SqlException ex) { Console.WriteLine(ex.Message); }",
    rubric: "Full: using blocks, @parameters, Open(), ExecuteNonQuery(), try/catch. Deduct for concatenation or missing error handling."
  },
  c_py_pascal: {
    topic: "Python",
    title: "Pascal's Triangle",
    q: "Write a Python program that generates and prints Pascal's Triangle for a given number of rows n.",
    model: "n = int(input())\nrow = [1]\nfor _ in range(n):\n    print(*row)\n    row = [1] + [row[i] + row[i+1] for i in range(len(row)-1)] + [1]",
    rubric: "Full: correct values for any n. Partial: off-by-one or formatting issues."
  },
  c_py_prime: {
    topic: "Python",
    title: "Prime check with input validation",
    q: "Write a Python program that checks whether a given number is prime. Wrap the input handling in try/except so non-integer input is reported gracefully instead of crashing.",
    model: "try:\n    n = int(input(\"Enter a number: \"))\nexcept ValueError:\n    print(\"Invalid input\")\nelse:\n    prime = n > 1 and all(n % i for i in range(2, int(n**0.5) + 1))\n    print(\"Prime\" if prime else \"Not prime\")",
    rubric: "Full: handles n<=1, loops to sqrt(n) (or at least correct), catches ValueError. Deduct if 1 is treated as prime or no try/except."
  },
  c_num_pyramid: {
    topic: "Programming (any language)",
    title: "Numeric pyramid",
    q: "Write a program (any language) that prints this numeric pyramid for n rows (shown for n = 6):\n\n          1\n        2 1 2\n      3 2 1 2 3\n    4 3 2 1 2 3 4\n  5 4 3 2 1 2 3 4 5\n6 5 4 3 2 1 2 3 4 5 6",
    model: "n = int(input())\nfor i in range(1, n+1):\n    nums = list(range(i, 0, -1)) + list(range(2, i+1))\n    print(\"  \" * (n - i) + \" \".join(map(str, nums)))",
    rubric: "Full: correct numbers and centered alignment. Partial: correct numbers, wrong alignment."
  },
  c_star_center: {
    topic: "Programming (any language)",
    title: "Centered star pyramid",
    q: "Write a program (any language) that prints a centered star pyramid for a given number of levels (shown for levels = 5):\n\n    *\n   ***\n  *****\n *******\n*********",
    model: "for i in range(levels):\n    print(\" \" * (levels - i - 1) + \"*\" * (2*i + 1))",
    rubric: "Full: (2i+1) stars with correct leading spaces. Partial: stars right, spacing wrong."
  },
  c_star_left: {
    topic: "Programming (any language)",
    title: "Left-aligned star pyramid",
    q: "Write a program (any language) that prints a left-aligned, increasing star pyramid for input n (shown for n = 5):\n\n*\n***\n*****\n*******\n*********",
    model: "for i in range(n):\n    print(\"*\" * (2*i + 1))",
    rubric: "Full: rows of 1,3,5,... stars. Partial: rows of 1,2,3,... stars."
  },
  c_first_standalone: {
    topic: "Programming (any language)",
    title: "First standalone character",
    q: "Given a string, find the first character that does NOT belong to any consecutive repeating group (a character is in a group if the same character appears immediately before or after it). Print \"No Character Found\" if none exists.\n\nInput: aabbccdefggd\nOutput: d\n\nAlso state what your program returns for \"aabbbcda\" and why.",
    model: "s = input()\nres = \"No Character Found\"\ni = 0\nwhile i < len(s):\n    j = i\n    while j < len(s) and s[j] == s[i]: j += 1\n    if j - i == 1:\n        res = s[i]; break\n    i = j\nprint(res)\n# 'aabbbcda' -> 'c' (first group of length 1)",
    rubric: "Full: groups consecutive runs, returns first run of length 1, handles not-found. Partial: uses global counts (that is the non-repeating problem, not this one)."
  },
  c_first_nonrep: {
    topic: "Programming (any language)",
    title: "First non-repeating character",
    q: "Given a string, write a program to find the first non-repeating character (a character that appears exactly once, returned in left-to-right order).\n\nExample: Input: \"aabbcdd\" → expected output: c",
    model: "from collections import Counter\ns = input()\nc = Counter(s)\nprint(next((ch for ch in s if c[ch] == 1), \"None\"))",
    rubric: "Full: counts frequencies then scans left-to-right. Partial: O(n²) but correct; deduct if returns wrong char for the example."
  },
  c_index_p: {
    topic: "Programming (any language)",
    title: "Index of a letter",
    q: "Given the word \"Apple\", write a short program or expression to find the position (index) of the letter 'P'. State clearly whether your answer uses 0-based or 1-based indexing.",
    model: "\"Apple\".lower().index(\"p\")   # 1 (0-based)  → position 2 (1-based)",
    rubric: "Full: correct index AND states the convention (0-based 1 / 1-based 2). Deduct if case-sensitivity is ignored without explanation."
  },
  c_java_servlet: {
    topic: "Java",
    title: "Login servlet",
    q: "Create a Java Servlet that handles a login form (username and password via HTTP POST) and displays a welcome message on success or an error on failure. Include the HTML login form and briefly describe the request flow.",
    model: "<form action=\"login\" method=\"post\">\n  <input name=\"username\"><input type=\"password\" name=\"password\"><button>Login</button>\n</form>\n\n@WebServlet(\"/login\")\npublic class LoginServlet extends HttpServlet {\n  protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {\n    String u = req.getParameter(\"username\"), p = req.getParameter(\"password\");\n    res.setContentType(\"text/html\");\n    PrintWriter out = res.getWriter();\n    if (\"admin\".equals(u) && \"admin\".equals(p)) out.println(\"<h2>Welcome \" + u + \"</h2>\");\n    else out.println(\"<h2>Invalid credentials</h2>\");\n  }\n}\nFlow: browser POSTs form → container routes /login to servlet → doPost reads parameters → validates → writes HTML response.",
    rubric: "Full: doPost, getParameter, PrintWriter output for both cases, form HTML, flow described. Partial: missing form or flow."
  },
  c_missing_num: {
    topic: "Programming (any language)",
    title: "Missing number",
    q: "An array contains numbers from 1 to N with one number missing. Read N and the array from the user at runtime and print the missing number.\n\nExample: arr = [1, 2, 3, 5], N = 5 → Output: 4",
    model: "n = int(input())\narr = list(map(int, input().split()))\nprint(n*(n+1)//2 - sum(arr))",
    rubric: "Full: reads input at runtime and uses sum or XOR formula. Partial: hard-coded array."
  },
  c_anagram: {
    topic: "Python",
    title: "Anagram check",
    q: "Write a Python program to check whether two strings are anagrams of each other.\n\nExample: Input: listen silent → Output: Anagram",
    model: "a, b = input().split()\nprint(\"Anagram\" if sorted(a.lower()) == sorted(b.lower()) else \"Not Anagram\")",
    rubric: "Full: sorted() or frequency-count comparison. Deduct for set() comparison (ignores counts)."
  },
  c_no_builtin: {
    topic: "Programming (any language)",
    title: "Reverse a string without built-ins",
    q: "Without using built-in functions/methods such as reverse(), reversed(), slicing [::-1], sorted() or StringBuilder, write a program that reverses a string entered by the user.",
    model: "s = input()\nr = \"\"\ni = len(s) - 1\nwhile i >= 0:\n    r += s[i]\n    i -= 1\nprint(r)",
    rubric: "Full: manual loop only. Deduct heavily if a built-in reverse/slice is used."
  },
  c_longest_group: {
    topic: "Programming (any language)",
    title: "Longest consecutive repeating group",
    q: "Given a string of lowercase letters, print the first character of the LONGEST consecutive repeating group. If several groups tie, return the earliest.\n\nInput: aaabbbbccdd\nOutput: b",
    model: "s = input()\nbest, best_len = \"\", 0\ni = 0\nwhile i < len(s):\n    j = i\n    while j < len(s) and s[j] == s[i]: j += 1\n    if j - i > best_len: best, best_len = s[i], j - i\n    i = j\nprint(best)",
    rubric: "Full: run-length scan with strict '>' so the earliest tie wins. Partial: counts global frequency instead of consecutive runs."
  },
  c_prime_triangle: {
    topic: "Programming (any language)",
    title: "Prime number triangle",
    q: "Print a right-angled triangle of consecutive prime numbers with N rows; row r contains r primes.\n\nInput: 5\nOutput:\n2\n3 5\n7 11 13\n17 19 23 29\n31 37 41 43 47",
    model: "def is_prime(x):\n    return x > 1 and all(x % i for i in range(2, int(x**0.5)+1))\nn = int(input()); p = 2\nfor r in range(1, n+1):\n    row = []\n    while len(row) < r:\n        if is_prime(p): row.append(p)\n        p += 1\n    print(*row)",
    rubric: "Full: correct prime generation and continuous sequence across rows. Partial: restarts primes each row."
  },
  c_topk: {
    topic: "Programming (any language)",
    title: "Top K frequent elements",
    q: "Given nums and k, return the k most frequent elements.\n\nInput: nums = [1,1,1,2,2,3,4,4,4,4], k = 2\nOutput: [4, 1]",
    model: "from collections import Counter\nprint([x for x, _ in Counter(nums).most_common(k)])",
    rubric: "Full: frequency map + sort/heap by count. Partial: correct idea, wrong ordering."
  },
  c_lwc_contacts: {
    topic: "Salesforce (LWC & Apex)",
    title: "LWC – related Contacts with Refresh",
    q: "Build a Lightning Web Component that (1) fetches Contacts related to an Account using an Apex controller method based on recordId, (2) displays them in a lightning-datatable, (3) has a Refresh button that reloads the latest data, and (4) shows a toast on error. Provide the Apex method, JS and HTML.",
    model: "// Apex\npublic with sharing class ContactController {\n  @AuraEnabled(cacheable=true)\n  public static List<Contact> getContacts(Id accountId) {\n    return [SELECT Id, Name, Email FROM Contact WHERE AccountId = :accountId];\n  }\n}\n// JS\nimport { LightningElement, api, wire } from 'lwc';\nimport { refreshApex } from '@salesforce/apex';\nimport { ShowToastEvent } from 'lightning/platformShowToastEvent';\nimport getContacts from '@salesforce/apex/ContactController.getContacts';\nexport default class AccountContacts extends LightningElement {\n  @api recordId; contacts; wired;\n  columns = [{label:'Name', fieldName:'Name'}, {label:'Email', fieldName:'Email'}];\n  @wire(getContacts, { accountId: '$recordId' })\n  wiredContacts(result) {\n    this.wired = result;\n    if (result.data) this.contacts = result.data;\n    else if (result.error) this.dispatchEvent(new ShowToastEvent({title:'Error', message: result.error.body.message, variant:'error'}));\n  }\n  handleRefresh() { refreshApex(this.wired); }\n}\n<!-- HTML -->\n<template>\n  <lightning-button label=\"Refresh\" onclick={handleRefresh}></lightning-button>\n  <lightning-datatable key-field=\"Id\" data={contacts} columns={columns}></lightning-datatable>\n</template>",
    rubric: "Full: @api recordId, @AuraEnabled(cacheable) Apex, @wire or imperative call, datatable, refreshApex, ShowToastEvent. Deduct per missing piece."
  },
  c_apex_future: {
    topic: "Salesforce (LWC & Apex)",
    title: "Apex trigger + @future email",
    q: "Write an Apex trigger on Account that, after a new Account is inserted, sends a Welcome Email asynchronously using a @future method.",
    model: "trigger AccountTrigger on Account (after insert) {\n  AccountEmailService.sendWelcome(new List<Id>(Trigger.newMap.keySet()));\n}\npublic class AccountEmailService {\n  @future\n  public static void sendWelcome(List<Id> accountIds) {\n    List<Messaging.SingleEmailMessage> mails = new List<Messaging.SingleEmailMessage>();\n    for (Account a : [SELECT Name, Owner.Email FROM Account WHERE Id IN :accountIds]) {\n      Messaging.SingleEmailMessage m = new Messaging.SingleEmailMessage();\n      m.setToAddresses(new String[]{ a.Owner.Email });\n      m.setSubject('Welcome ' + a.Name);\n      m.setPlainTextBody('Welcome aboard!');\n      mails.add(m);\n    }\n    if (!mails.isEmpty()) Messaging.sendEmail(mails);\n  }\n}",
    rubric: "Full: after insert, passes Ids (not sObjects) to @future, bulk-safe, Messaging.sendEmail. Deduct if sObjects passed to @future or SOQL inside loop."
  }
};

/* Each set = 7 MCQ + 3 CODE. Sets are distinct patterns; every topic is represented in each set. */
const SETS = {
  1:  { mcq: ["sql1","cs1","py1","py5","jv1","js1","sf1"],  code: ["c_sql_second","c_py_pascal","c_lwc_contacts"] },
  2:  { mcq: ["sql3","cs2","py3","py6","jv2","js2","sf5"],  code: ["c_sql_highest","c_py_prime","c_apex_future"] },
  3:  { mcq: ["sql5","cs5","py2","py7","jv3","js3","sf3"],  code: ["c_cs_insert","c_num_pyramid","c_first_standalone"] },
  4:  { mcq: ["sql4","cs3","py4","py8","jv4","js4","sf6"],  code: ["c_sql_dup","c_star_center","c_first_nonrep"] },
  5:  { mcq: ["sql7","cs4","py10","py13","jv5","js5","sf2"], code: ["c_sql_second","c_java_servlet","c_missing_num"] },
  6:  { mcq: ["sql2","cs6","py9","py14","jv6","js6","sf4"],  code: ["c_cs_insert","c_anagram","c_longest_group"] },
  7:  { mcq: ["sql6","cs7","py11","py15","jv7","js1","sf7"], code: ["c_sql_highest","c_star_left","c_prime_triangle"] },
  8:  { mcq: ["sql8","cs1","py12","py3","jv2","js2","sf8"],  code: ["c_py_prime","c_index_p","c_lwc_contacts"] },
  9:  { mcq: ["sql1","cs5","py5","py8","jv4","js4","sf5"],   code: ["c_sql_dup","c_no_builtin","c_apex_future"] },
  10: { mcq: ["sql3","cs2","py6","py10","jv1","js6","sf3"],  code: ["c_py_pascal","c_topk","c_java_servlet"] }
};

/* Marks */
const MARKS = { mcq: 10, code: 10 };       // 7×10 + 3×10 = 100 per set
const PASS_PERCENT = 80;
const DURATION_MINUTES = 30;
