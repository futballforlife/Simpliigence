# Technical Evaluation – online test

A dependency-free, static online test (plain HTML/CSS/JS, no build step, no external libraries, no licenses) that runs on GitHub Pages.

* **10 sets** (Set 1 – Set 10), each with **7 multiple-choice + 3 coding questions**, 30 minutes, 10 marks per question.
* Multiple-choice questions are **auto-scored**; coding answers are graded by the organizer on `organizer.html`.
* **Pass mark: 80 %**.
* Topics: SQL, C#/ADO.NET, Python, Java, JavaScript, Salesforce (LWC & Apex).

## Files

| File | Purpose |
|---|---|
| `index.html` | The test candidates take. Open with `?set=N` (N = 1…10). |
| `organizer.html` | Organizer console: paste a submission code → auto-scored MCQs, grade coding answers, PASS/FAIL, candidate links, answer key, CSV export. |
| `questions.js` | Question bank and the 10 set definitions. Edit to change questions or sets. |
| `config.js` | Organizer email, test title, options. |
| `common.js`, `style.css` | Shared helpers and styling. |

## Candidate links

```
https://<user>.github.io/<repo>/?set=1
https://<user>.github.io/<repo>/?set=2
...
https://<user>.github.io/<repo>/?set=10
```
Organizer console: `https://<user>.github.io/<repo>/organizer.html`

## How results reach the organizer

GitHub Pages is static, so nothing is stored on a server. When a candidate submits, they get a **submission code** (`TE1.…`) containing all their answers plus a checksum. They send it with the **"Email result to organizer"** button (opens their mail app addressed to the email in `config.js`) or paste it into the Teams chat. The organizer pastes the code into `organizer.html` to see the auto-scored MCQs, grade the 3 coding answers against the model answer/rubric, and get the final percentage and PASS/FAIL.

## Running the test on MS Teams

1. Send each candidate their set link (Organizer console → *Candidate links*).
2. Ask the candidate to share their screen while taking the test (optional).
3. After they submit, they email the code or paste it in the meeting chat.
4. Open `organizer.html`, paste the code, enter marks for the coding answers, and save/print the result.

## Customising

* Change the organizer email / title in `config.js`.
* Add or edit questions in `questions.js` (`MCQ`, `CODE`) and adjust `SETS`.
* Duration, marks and pass mark are at the bottom of `questions.js`.
