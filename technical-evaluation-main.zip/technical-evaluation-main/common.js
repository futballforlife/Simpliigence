/* Shared helpers for index.html and organizer.html */

function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

/* FNV-1a 32-bit hash – lightweight tamper check for submission codes */
function fnv1a(str) {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h.toString(16).padStart(8, "0");
}

function b64uEncode(str) {
  const bytes = new TextEncoder().encode(str);
  let bin = "";
  bytes.forEach(b => bin += String.fromCharCode(b));
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function b64uDecode(s) {
  s = s.replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4) s += "=";
  const bin = atob(s);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new TextDecoder().decode(bytes);
}

/* Submission code format:  TE1.<hash>.<base64url(json)> */
function encodeResult(obj) {
  const json = JSON.stringify(obj);
  return "TE1." + fnv1a(json) + "." + b64uEncode(json);
}
function decodeResult(code) {
  code = String(code || "").trim().replace(/\s+/g, "");
  const m = code.match(/^TE1\.([0-9a-f]{8})\.([A-Za-z0-9_-]+)$/);
  if (!m) throw new Error("This does not look like a valid submission code.");
  const json = b64uDecode(m[2]);
  const ok = fnv1a(json) === m[1];
  return { data: JSON.parse(json), verified: ok };
}

/* Seeded PRNG (mulberry32) + shuffle so option order is stable for one attempt */
function rng(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function shuffledIndexes(n, seed) {
  const idx = [...Array(n).keys()];
  const r = rng(seed);
  for (let i = n - 1; i > 0; i--) {
    const j = Math.floor(r() * (i + 1));
    [idx[i], idx[j]] = [idx[j], idx[i]];
  }
  return idx;
}

/* Score the MCQ part of a decoded result */
function scoreMcq(result) {
  let correct = 0;
  const rows = result.mcq.map(a => {
    const q = MCQ[a.id];
    const isCorrect = q && a.chosen === q.answer;
    if (isCorrect) correct++;
    return { id: a.id, q, chosen: a.chosen, correct: !!isCorrect };
  });
  return { rows, correct, total: result.mcq.length, marks: correct * MARKS.mcq, maxMarks: result.mcq.length * MARKS.mcq };
}

function fmtDuration(sec) {
  sec = Math.max(0, Math.round(sec));
  const m = Math.floor(sec / 60), s = sec % 60;
  return m + "m " + String(s).padStart(2, "0") + "s";
}
function fmtDate(iso) {
  try { return new Date(iso).toLocaleString(); } catch { return iso; }
}
/* Render option text – options that contain literal "\n" are multi-line code */
function optionHtml(text) {
  if (text.includes("\\n")) return '<code class="opt-code">' + esc(text).replace(/\\n/g, "<br>") + "</code>";
  return esc(text);
}
